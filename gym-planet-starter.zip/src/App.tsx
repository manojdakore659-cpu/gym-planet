import { useEffect, useMemo, useState } from 'react'
import { Html5QrcodeScanner } from 'html5-qrcode'
import { QRCodeSVG } from 'qrcode.react'
import {
  Activity, Bell, ChevronDown, CreditCard, Dumbbell, LayoutDashboard,
  LogOut, Menu, Package, Plus, QrCode, Search, Settings, ShoppingBag,
  Users, X, CalendarCheck, TrendingUp, AlertCircle, CheckCircle2
} from 'lucide-react'
import { isSupabaseConfigured, supabase } from './lib/supabase'

type Member = {
  id: string; full_name: string; phone: string; email?: string | null
  plan_name?: string | null; membership_end?: string | null; status: string
  created_at?: string
}
type Product = { id: string; name: string; price: number; stock: number; category?: string }
type Attendance = { id: string; member_id: string; attended_on: string; member?: { full_name: string } }

const demoMembers: Member[] = [
  { id: 'GP-1001', full_name: 'Aarav Sharma', phone: '9876543210', plan_name: 'Yearly', membership_end: '2027-08-10', status: 'active' },
  { id: 'GP-1002', full_name: 'Ishita Patil', phone: '9876543211', plan_name: 'Quarterly', membership_end: '2026-12-15', status: 'active' },
  { id: 'GP-1003', full_name: 'Rohan Verma', phone: '9876543212', plan_name: 'Monthly', membership_end: '2026-11-20', status: 'active' },
  { id: 'GP-1004', full_name: 'Sana Khan', phone: '9876543213', plan_name: 'Half-Yearly', membership_end: '2026-10-30', status: 'expired' },
]
const demoProducts: Product[] = [
  { id: 'P-1', name: 'Whey Protein', price: 2499, stock: 12, category: 'Supplements' },
  { id: 'P-2', name: 'Gym Shaker', price: 299, stock: 28, category: 'Accessories' },
  { id: 'P-3', name: 'Resistance Band', price: 499, stock: 7, category: 'Equipment' },
]

type Page = 'Overview' | 'Members' | 'Attendance' | 'Memberships' | 'Store' | 'Settings'

export default function App() {
  const [page, setPage] = useState<Page>('Overview')
  const [members, setMembers] = useState<Member[]>(demoMembers)
  const [products, setProducts] = useState<Product[]>(demoProducts)
  const [attendance, setAttendance] = useState<Attendance[]>([])
  const [search, setSearch] = useState('')
  const [showAdd, setShowAdd] = useState(false)
  const [showProduct, setShowProduct] = useState(false)
  const [selectedMember, setSelectedMember] = useState<Member | null>(null)
  const [mobileNav, setMobileNav] = useState(false)
  const [notice, setNotice] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!supabase) return
    let alive = true
    const load = async () => {
      setLoading(true)
      const [m, p, a] = await Promise.all([
        supabase!.from('members').select('*').order('created_at', { ascending: false }),
        supabase!.from('products').select('*').order('created_at', { ascending: false }),
        supabase!.from('attendance').select('id,member_id,attended_on,members(full_name)').order('created_at', { ascending: false }).limit(12)
      ])
      if (!alive) return
      if (!m.error && m.data) setMembers(m.data as Member[])
      if (!p.error && p.data) setProducts(p.data as Product[])
      if (!a.error && a.data) setAttendance(a.data as unknown as Attendance[])
      setLoading(false)
    }
    void load()
    return () => { alive = false }
  }, [])

  const active = members.filter(m => m.status === 'active').length
  const today = new Date().toISOString().slice(0, 10)
  const todayCount = attendance.filter(a => a.attended_on === today).length
  const filteredMembers = useMemo(() => members.filter(m =>
    `${m.full_name} ${m.phone} ${m.id}`.toLowerCase().includes(search.toLowerCase())
  ), [members, search])

  const flash = (message: string) => { setNotice(message); window.setTimeout(() => setNotice(''), 3200) }

  async function addMember(data: { full_name: string; phone: string; email: string; plan_name: string }) {
    const member = { id: `GP-${Date.now().toString().slice(-7)}`, ...data, status: 'active' }
    if (supabase) {
      const { data: saved, error } = await supabase.from('members').insert(member).select().single()
      if (error) return flash(error.message)
      setMembers(prev => [saved as Member, ...prev])
    } else setMembers(prev => [member, ...prev])
    setShowAdd(false); flash('Member added successfully')
  }

  async function addProduct(data: { name: string; price: number; stock: number; category: string }) {
    const product = { id: `P-${Date.now()}`, ...data }
    if (supabase) {
      const { data: saved, error } = await supabase.from('products').insert(product).select().single()
      if (error) return flash(error.message)
      setProducts(prev => [saved as Product, ...prev])
    } else setProducts(prev => [product, ...prev])
    setShowProduct(false); flash('Product added successfully')
  }

  async function markAttendance(memberId: string) {
    const member = members.find(m => m.id === memberId || m.id.toLowerCase() === memberId.toLowerCase())
    if (!member) return flash('Member ID not found')
    const already = attendance.some(a => a.member_id === member.id && a.attended_on === today)
    if (already) return flash('Attendance already marked today')
    if (supabase) {
      const { data, error } = await supabase.from('attendance')
        .insert({ member_id: member.id, attended_on: today })
        .select().single()
      if (error) return flash(error.message.includes('duplicate') ? 'Attendance already marked today' : error.message)
      setAttendance(prev => [{ ...(data as Attendance), member: { full_name: member.full_name } }, ...prev])
    } else setAttendance(prev => [{ id: crypto.randomUUID(), member_id: member.id, attended_on: today, member: { full_name: member.full_name } }, ...prev])
    flash(`Attendance marked for ${member.full_name}`)
  }

  async function deleteMember(member: Member) {
    if (!confirm(`Delete ${member.full_name}? This cannot be undone.`)) return
    if (supabase) {
      const { error } = await supabase.from('members').delete().eq('id', member.id)
      if (error) return flash(error.message)
    }
    setMembers(prev => prev.filter(m => m.id !== member.id))
    setSelectedMember(null); flash('Member deleted')
  }

  const nav: { label: Page; icon: typeof LayoutDashboard }[] = [
    { label: 'Overview', icon: LayoutDashboard }, { label: 'Members', icon: Users },
    { label: 'Attendance', icon: QrCode }, { label: 'Memberships', icon: CreditCard },
    { label: 'Store', icon: ShoppingBag }, { label: 'Settings', icon: Settings }
  ]

  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? 'open' : ''}`}>
      <div className="brand"><div className="brand-icon"><Dumbbell size={23}/></div><div><b>GYM <span>PLANET</span></b><small>MANAGEMENT SYSTEM</small></div><button className="mobile-close" onClick={() => setMobileNav(false)}><X/></button></div>
      <div className="nav-label">WORKSPACE</div>
      <nav>{nav.map(item => <button key={item.label} className={`nav-item ${page === item.label ? 'active' : ''}`} onClick={() => { setPage(item.label); setMobileNav(false) }}><item.icon size={18}/>{item.label}{page === item.label && <span className="nav-dot"/>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="status-line"><span className="live-dot"/> SYSTEM ONLINE</div><div className="profile-mini"><div className="avatar">A</div><div><b>Gym Admin</b><small>Administrator</small></div><ChevronDown size={16}/></div></div>
    </aside>
    {mobileNav && <div className="scrim" onClick={() => setMobileNav(false)}/>}
    <main className="main-area">
      <header className="topbar"><button className="menu-button" onClick={() => setMobileNav(true)}><Menu/></button><div className="breadcrumb">Workspace <span>/</span> <b>{page}</b></div><div className="top-actions"><div className={`connection ${isSupabaseConfigured ? 'connected' : ''}`}><span/> {isSupabaseConfigured ? 'DATABASE CONNECTED' : 'DEMO MODE'}</div><button className="icon-button" title="Notifications"><Bell size={18}/></button><div className="avatar small">A</div></div></header>
      <div className="content">
        {notice && <div className="toast"><CheckCircle2 size={17}/>{notice}</div>}
        {page === 'Overview' && <Overview members={members} active={active} todayCount={todayCount} products={products} attendance={attendance} loading={loading} onAdd={() => setShowAdd(true)} onScan={() => setPage('Attendance')}/>}
        {page === 'Members' && <section><PageHeading title="Members" subtitle="Manage your gym community and membership records." action={<button className="primary-btn" onClick={() => setShowAdd(true)}><Plus size={17}/> Add Member</button>}/><div className="panel"><div className="panel-toolbar"><div className="searchbox"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name, phone or member ID..."/></div><span className="muted">{filteredMembers.length} members</span></div><MembersTable members={filteredMembers} onSelect={setSelectedMember}/></div></section>}
        {page === 'Attendance' && <AttendancePage members={members} attendance={attendance} onMark={markAttendance} flash={flash}/>}
        {page === 'Memberships' && <MembershipPage members={members}/>}
        {page === 'Store' && <StorePage products={products} onAdd={() => setShowProduct(true)}/>}
        {page === 'Settings' && <SettingsPage configured={isSupabaseConfigured}/>}
      </div>
    </main>
    {showAdd && <MemberModal onClose={() => setShowAdd(false)} onSave={addMember}/>}
    {showProduct && <ProductModal onClose={() => setShowProduct(false)} onSave={addProduct}/>}
    {selectedMember && <MemberDetail member={selectedMember} onClose={() => setSelectedMember(null)} onDelete={() => deleteMember(selectedMember)}/>}
  </div>
}

function PageHeading({ title, subtitle, action }: { title: string; subtitle: string; action?: React.ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow">GYM PLANET / MANAGEMENT</div><h1>{title}</h1><p>{subtitle}</p></div>{action}</div>
}
function Overview({ members, active, todayCount, products, attendance, loading, onAdd, onScan }: { members: Member[]; active: number; todayCount: number; products: Product[]; attendance: Attendance[]; loading: boolean; onAdd: () => void; onScan: () => void }) {
  const expired = members.filter(m => m.status === 'expired').length
  const lowStock = products.filter(p => p.stock <= 10).length
  return <section><PageHeading title="Dashboard Overview" subtitle="Here's what's happening at your gym today." action={<div className="heading-actions"><button className="outline-btn" onClick={onScan}><QrCode size={17}/> Scan QR</button><button className="primary-btn" onClick={onAdd}><Plus size={17}/> Add Member</button></div>}/>
    {loading && <div className="loading-line">Syncing your gym data…</div>}
    <div className="stats-grid">
      <Stat icon={<Users/>} label="Total Members" value={members.length.toString()} note={`${active} active members`} tone="green"/>
      <Stat icon={<CalendarCheck/>} label="Today's Attendance" value={todayCount.toString()} note="Recorded check-ins" tone="blue"/>
      <Stat icon={<CreditCard/>} label="Active Memberships" value={active.toString()} note={`${expired} expired`} tone="purple"/>
      <Stat icon={<Package/>} label="Low Stock Products" value={lowStock.toString()} note="10 or fewer in stock" tone="orange"/>
    </div>
    <div className="dashboard-grid"><div className="panel"><div className="panel-title"><div><h3>Recent Members</h3><p>Latest people joining your gym</p></div><button className="text-btn" onClick={() => document.querySelector<HTMLButtonElement>('[data-nav="Members"]')?.click()}>View all</button></div><MembersTable members={members.slice(0, 5)} compact/></div>
      <div className="panel"><div className="panel-title"><div><h3>Quick Actions</h3><p>Common management tasks</p></div></div><div className="quick-actions"><button onClick={onAdd}><span className="quick-icon green-bg"><Users/></span><span><b>Add new member</b><small>Create a member profile</small></span><Plus size={17}/></button><button onClick={onScan}><span className="quick-icon blue-bg"><QrCode/></span><span><b>Mark attendance</b><small>Scan a member QR code</small></span><ChevronDown size={17}/></button><div className="tip-box"><Activity size={17}/><span><b>Keep the momentum</b><small>Check attendance regularly to keep your gym running smoothly.</small></span></div></div></div></div>
    <div className="panel recent-panel"><div className="panel-title"><div><h3>Recent Check-ins</h3><p>Latest attendance records</p></div><span className="live-tag">LIVE ACTIVITY</span></div>{attendance.length ? <div className="activity-list">{attendance.slice(0, 5).map(a => <div className="activity-row" key={a.id}><div className="activity-icon"><CheckCircle2 size={17}/></div><div><b>{a.member?.full_name || members.find(m => m.id === a.member_id)?.full_name || a.member_id}</b><small>Attendance recorded</small></div><time>{a.attended_on}</time></div>)}</div> : <EmptyState title="No attendance records yet" detail="Scan a member's QR code to record the first check-in."/>}</div>
  </section>
}
function Stat({ icon, label, value, note, tone }: { icon: React.ReactNode; label: string; value: string; note: string; tone: string }) {
  return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-note"><TrendingUp size={13}/>{note}</div></div>
}
function MembersTable({ members, onSelect, compact = false }: { members: Member[]; onSelect?: (m: Member) => void; compact?: boolean }) {
  if (!members.length) return <EmptyState title="No members found" detail="Add your first member to get started."/>
  return <div className="table-wrap"><table><thead><tr><th>MEMBER</th><th>MEMBER ID</th><th>PLAN</th><th>STATUS</th>{!compact && <th>EXPIRY DATE</th>}</tr></thead><tbody>{members.map(m => <tr key={m.id} onClick={() => onSelect?.(m)} className={onSelect ? 'clickable' : ''}><td><div className="member-cell"><div className="avatar">{m.full_name.slice(0,1).toUpperCase()}</div><div><b>{m.full_name}</b><small>{m.phone}</small></div></div></td><td className="mono">{m.id}</td><td>{m.plan_name || 'Not assigned'}</td><td><span className={`pill ${m.status === 'active' ? 'success' : 'danger'}`}>{m.status}</span></td>{!compact && <td>{m.membership_end || '—'}</td>}</tr>)}</tbody></table></div>
}
function AttendancePage({ members, attendance, onMark, flash }: { members: Member[]; attendance: Attendance[]; onMark: (id: string) => void; flash: (s: string) => void }) {
  const [manualId, setManualId] = useState('')
  useEffect(() => {
    const scanner = new Html5QrcodeScanner('qr-reader', { fps: 10, qrbox: { width: 220, height: 220 }, rememberLastUsedCamera: true }, false)
    scanner.render(decoded => {
      const value = decoded.startsWith('GYMPLANET:') ? decoded.slice(10) : decoded
      onMark(value)
      void scanner.clear().catch(() => undefined)
    }, () => undefined)
    return () => { void scanner.clear().catch(() => undefined) }
  }, [onMark])
  return <section><PageHeading title="QR Attendance" subtitle="Scan member QR codes or enter a member ID manually."/><div className="attendance-grid"><div className="panel scanner-panel"><div className="panel-title"><div><h3><QrCode size={19}/> QR Code Scanner</h3><p>Allow camera access to scan a member's code.</p></div><span className="live-tag">SCANNER</span></div><div id="qr-reader"/><div className="manual-entry"><label>Manual member ID</label><div className="inline-form"><input value={manualId} onChange={e => setManualId(e.target.value)} placeholder="e.g. GP-1001"/><button className="primary-btn" onClick={() => { if (!manualId.trim()) return flash('Enter a member ID'); onMark(manualId.trim()); setManualId('') }}>Mark present</button></div></div><div className="hint"><AlertCircle size={16}/> Camera access requires HTTPS or localhost. Use manual entry if camera scanning is unavailable.</div></div><div className="panel"><div className="panel-title"><div><h3>Member QR Codes</h3><p>Select a member to display their unique QR.</p></div></div><div className="qr-member-list">{members.slice(0, 8).map(m => <div key={m.id} className="qr-member" onClick={() => flash(`Member QR: ${m.id} — open member profile to view printable QR`)}><div className="avatar">{m.full_name[0]}</div><div><b>{m.full_name}</b><small>{m.id}</small></div><span className="pill success">View ID</span></div>)}</div><div className="small-note">Member profile includes a downloadable QR code.</div></div></div><div className="panel recent-panel"><div className="panel-title"><div><h3>Attendance History</h3><p>Latest recorded check-ins</p></div></div>{attendance.length ? <div className="activity-list">{attendance.map(a => <div className="activity-row" key={a.id}><div className="activity-icon"><CheckCircle2 size={17}/></div><div><b>{a.member?.full_name || members.find(m => m.id === a.member_id)?.full_name || a.member_id}</b><small>{a.member_id}</small></div><time>{a.attended_on}</time></div>)}</div> : <EmptyState title="No check-ins yet" detail="Your attendance records will appear here."/></div>}</section>
}
function MembershipPage({ members }: { members: Member[] }) {
  const plans = [{ name: 'Monthly', duration: '30 days', price: 'Set your price', color: 'green' }, { name: 'Quarterly', duration: '90 days', price: 'Set your price', color: 'blue' }, { name: 'Half-Yearly', duration: '180 days', price: 'Set your price', color: 'purple' }, { name: 'Yearly', duration: '365 days', price: 'Set your price', color: 'orange' }]
  return <section><PageHeading title="Membership Plans" subtitle="View plan distribution and member expiry information."/><div className="plan-grid">{plans.map(p => <div className="plan-card" key={p.name}><div className={`plan-icon ${p.color}`}><CreditCard/></div><h3>{p.name}</h3><p>{p.duration}</p><b>{members.filter(m => m.plan_name?.toLowerCase() === p.name.toLowerCase()).length} <small>members</small></b><span className="muted">{p.price}</span></div>)}</div><div className="panel"><div className="panel-title"><div><h3>Membership register</h3><p>Member plan and expiry overview</p></div></div><MembersTable members={members}/></div></section>
}
function StorePage({ products, onAdd }: { products: Product[]; onAdd: () => void }) {
  return <section><PageHeading title="Supplement Store" subtitle="Manage your gym products, pricing and inventory." action={<button className="primary-btn" onClick={onAdd}><Plus size={17}/> Add Product</button>}/><div className="product-grid">{products.map(p => <div className="product-card" key={p.id}><div className="product-art"><Package size={34}/><span>{p.category || 'GYM PLANET'}</span></div><div className="product-info"><small>{p.category || 'Product'}</small><h3>{p.name}</h3><div className="product-bottom"><b>₹{Number(p.price).toLocaleString('en-IN')}</b><span className={`pill ${p.stock <= 10 ? 'warning' : 'success'}`}>{p.stock} in stock</span></div></div></div>)}{!products.length && <EmptyState title="No products yet" detail="Add your first store product."/ >}</div></section>
}
function SettingsPage({ configured }: { configured: boolean }) {
  return <section><PageHeading title="Settings" subtitle="Configure your GYM PLANET workspace."/><div className="panel settings-panel"><div className="setting-row"><div><b>Database connection</b><small>Supabase project connection status</small></div><span className={`pill ${configured ? 'success' : 'warning'}`}>{configured ? 'Connected' : 'Not configured'}</span></div><div className="setting-row"><div><b>Gym profile</b><small>Gym name, address and contact details</small></div><span className="pill warning">Setup required</span></div><div className="setting-row"><div><b>Payment gateway</b><small>Configure a provider and verified server-side webhooks before accepting payments.</small></div><span className="pill warning">Not configured</span></div><div className="setting-row"><div><b>Staff accounts</b><small>Set up Supabase Auth and role policies before inviting staff.</small></div><span className="pill warning">Setup required</span></div><div className="security-note"><AlertCircle size={18}/><div><b>Security reminder</b><p>Never put Supabase service-role keys, payment secrets or private API keys in frontend code or GitHub. Use server-side functions for privileged actions.</p></div></div></div></section>
}
function MemberModal({ onClose, onSave }: { onClose: () => void; onSave: (d: { full_name: string; phone: string; email: string; plan_name: string }) => void }) {
  const [form, setForm] = useState({ full_name: '', phone: '', email: '', plan_name: 'Monthly' })
  const [error, setError] = useState('')
  const change = (key: keyof typeof form, value: string) => setForm(prev => ({ ...prev, [key]: value }))
  return <Modal title="Add new member" onClose={onClose}><form onSubmit={e => { e.preventDefault(); if (form.full_name.trim().length < 2) return setError('Enter the member name'); if (!/^[0-9]{10}$/.test(form.phone)) return setError('Enter a valid 10-digit phone number'); setError(''); onSave(form) }}><label>Full name</label><input required value={form.full_name} onChange={e => change('full_name', e.target.value)} placeholder="Member full name"/><label>Phone number</label><input required value={form.phone} onChange={e => change('phone', e.target.value)} placeholder="10-digit mobile number" inputMode="numeric"/><label>Email (optional)</label><input type="email" value={form.email} onChange={e => change('email', e.target.value)} placeholder="member@example.com"/><label>Membership plan</label><select value={form.plan_name} onChange={e => change('plan_name', e.target.value)}><option>Monthly</option><option>Quarterly</option><option>Half-Yearly</option><option>Yearly</option></select>{error && <p className="form-error">{error}</p>}<div className="modal-actions"><button type="button" className="outline-btn" onClick={onClose}>Cancel</button><button className="primary-btn" type="submit">Save member</button></div></form></Modal>
}
function ProductModal({ onClose, onSave }: { onClose: () => void; onSave: (d: { name: string; price: number; stock: number; category: string }) => void }) {
  const [form, setForm] = useState({ name: '', price: '0', stock: '0', category: 'Supplements' })
  return <Modal title="Add store product" onClose={onClose}><form onSubmit={e => { e.preventDefault(); if (!form.name.trim()) return; onSave({ name: form.name, price: Number(form.price), stock: Number(form.stock), category: form.category }) }}><label>Product name</label><input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Product name"/><label>Category</label><select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}><option>Supplements</option><option>Accessories</option><option>Equipment</option><option>Vitamins</option></select><div className="form-two"><div><label>Price (₹)</label><input type="number" min="0" required value={form.price} onChange={e => setForm({ ...form, price: e.target.value })}/></div><div><label>Stock</label><input type="number" min="0" required value={form.stock} onChange={e => setForm({ ...form, stock: e.target.value })}/></div></div><div className="modal-actions"><button type="button" className="outline-btn" onClick={onClose}>Cancel</button><button className="primary-btn" type="submit">Save product</button></div></form></Modal>
}
function MemberDetail({ member, onClose, onDelete }: { member: Member; onClose: () => void; onDelete: () => void }) {
  return <Modal title="Member profile" onClose={onClose}><div className="member-profile"><div className="avatar large">{member.full_name[0]}</div><h2>{member.full_name}</h2><span className="mono">{member.id}</span><span className={`pill ${member.status === 'active' ? 'success' : 'danger'}`}>{member.status}</span></div><div className="member-facts"><div><small>PHONE</small><b>{member.phone}</b></div><div><small>EMAIL</small><b>{member.email || 'Not provided'}</b></div><div><small>PLAN</small><b>{member.plan_name || 'Not assigned'}</b></div><div><small>EXPIRY</small><b>{member.membership_end || 'Not set'}</b></div></div><div className="member-qr"><QRCodeSVG value={`GYMPLANET:${member.id}`} size={150} level="M"/><b>Member attendance QR</b><small>Show this code to authorized gym staff.</small><button className="outline-btn" onClick={() => window.print()}>Print profile / QR</button></div><button className="danger-btn full" onClick={onDelete}><LogOut size={16}/> Delete member</button></Modal>
}
function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose() }}><div className="modal"><div className="modal-head"><h2>{title}</h2><button className="icon-button" onClick={onClose}><X/></button></div>{children}</div></div>
}
function EmptyState({ title, detail }: { title: string; detail: string }) { return <div className="empty-state"><div><Activity size={22}/></div><b>{title}</b><p>{detail}</p></div> }
