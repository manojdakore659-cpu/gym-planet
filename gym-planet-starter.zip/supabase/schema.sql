-- GYM PLANET database schema
-- Run this file in Supabase SQL Editor.
-- IMPORTANT: For production, add Supabase Auth + role-based policies before inviting users.

create extension if not exists pgcrypto;

create table if not exists public.members (
  id text primary key,
  full_name text not null check (char_length(full_name) >= 2),
  phone text not null,
  email text,
  plan_name text,
  membership_end date,
  status text not null default 'active' check (status in ('active','expired','inactive')),
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id text primary key,
  name text not null,
  price numeric(10,2) not null default 0 check (price >= 0),
  stock integer not null default 0 check (stock >= 0),
  category text,
  created_at timestamptz not null default now()
);

create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  member_id text not null references public.members(id) on delete cascade,
  attended_on date not null default current_date,
  created_at timestamptz not null default now(),
  unique(member_id, attended_on)
);

create index if not exists members_phone_idx on public.members(phone);
create index if not exists attendance_date_idx on public.attendance(attended_on desc);
create index if not exists attendance_member_idx on public.attendance(member_id, attended_on desc);
create index if not exists products_category_idx on public.products(category);

-- Enable RLS. The policies below are suitable ONLY for initial private testing
-- when the anon key is used by a trusted developer in a non-public test project.
-- Do NOT deploy a public gym database with unrestricted policies.
alter table public.members enable row level security;
alter table public.products enable row level security;
alter table public.attendance enable row level security;

-- Initial development policies: allow anon CRUD for testing only.
-- Before production, DROP these policies and replace them with authenticated,
-- role-aware policies backed by a profiles table and server-verified roles.
create policy "dev_members_select" on public.members for select to anon using (true);
create policy "dev_members_insert" on public.members for insert to anon with check (true);
create policy "dev_members_update" on public.members for update to anon using (true) with check (true);
create policy "dev_members_delete" on public.members for delete to anon using (true);

create policy "dev_products_select" on public.products for select to anon using (true);
create policy "dev_products_insert" on public.products for insert to anon with check (true);
create policy "dev_products_update" on public.products for update to anon using (true) with check (true);
create policy "dev_products_delete" on public.products for delete to anon using (true);

create policy "dev_attendance_select" on public.attendance for select to anon using (true);
create policy "dev_attendance_insert" on public.attendance for insert to anon with check (
  exists (select 1 from public.members m where m.id = member_id and m.status = 'active')
);
create policy "dev_attendance_delete" on public.attendance for delete to anon using (true);

-- Production hardening checklist:
-- 1. Create profiles table referencing auth.users.
-- 2. Assign roles (owner/admin/staff/member) server-side; never trust client-supplied roles.
-- 3. Replace every dev_* policy with authenticated policies checking the user's role.
-- 4. Members should only read their own profile and attendance.
-- 5. Staff should only mark attendance; owner/admin can manage records.
-- 6. Move privileged operations and payment verification into Supabase Edge Functions.
-- 7. Never expose the service_role key in the browser.
