# GYM PLANET

A responsive gym-management dashboard starter built with React, Vite, TypeScript and Supabase.

## Included in this starter

- Admin-style dashboard overview
- Member list, search, add and delete
- Member profile with QR code
- QR scanner using the device camera (HTTPS/localhost required)
- Manual attendance entry
- Duplicate same-day attendance prevention (database unique constraint)
- Basic membership overview
- Supplement/product inventory list and add product
- Supabase schema and environment template
- Mobile-responsive dark fitness UI

## Important scope notes

This is a working **MVP starter**, not yet a production-ready gym business platform. The initial screen uses demo data when Supabase is not configured. The Supabase SQL file contains explicitly marked development-only anonymous policies so you can test quickly; these are NOT safe for a public production deployment.

Not included yet: payment gateway, online checkout, order management, email/SMS notifications, staff/member authentication, role-based access, image uploads, and production streak calculation. These should be added before public launch.

## Requirements

- Node.js 20 or newer
- A Supabase project (optional for local demo)

## Run locally

```bash
npm install
cp .env.example .env
# Add your Supabase project URL and anon key to .env
npm run dev
```

Open the local URL printed by Vite.

## Connect Supabase

1. Create a Supabase project.
2. Open SQL Editor.
3. Run `supabase/schema.sql`.
4. In Project Settings > API, copy the Project URL and anon/public key.
5. Put them in `.env` as `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
6. Restart the dev server.

Never put the Supabase `service_role` key in `.env` for this frontend project.

## GitHub

Create a repository named `gym-planet`, then:

```bash
git init
git add .
git commit -m "Initial GYM PLANET app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/gym-planet.git
git push -u origin main
```

Do not commit `.env`. It is excluded by `.gitignore`.

## Deploy

You can deploy the Vite app to Vercel:

- Import the GitHub repository in Vercel.
- Framework preset: Vite.
- Build command: `npm run build`.
- Output directory: `dist`.
- Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` as Vercel environment variables.
- Redeploy after adding environment variables.

QR camera access requires HTTPS in production.

## Production security checklist

Before using real member data:
- Replace the development RLS policies in `supabase/schema.sql`.
- Add Supabase Auth and server-verified roles.
- Restrict members to their own data.
- Restrict staff permissions to their duties.
- Add audit logs for admin changes.
- Add server-side QR token validation with expiry/nonce and anti-replay controls.
- Configure verified payment webhooks in a server-side function.
- Add backups, privacy notice, consent and data retention rules.
- Test authorization with separate owner, staff and member accounts.

## License

Private project starter. Add your own license before making the repository public.
